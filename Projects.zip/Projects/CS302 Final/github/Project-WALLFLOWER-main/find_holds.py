import cv2
import numpy as np
import subprocess
import os

#finds the holds in the given image
def detect_holds(image_path):
    # Check if the image file exists
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"Image file not found: {image_path}")

    # Load image
    image = cv2.imread(image_path)
    if image is None:
        raise ValueError(f"Failed to load image: {image_path}")

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Applies blur (adjust for better detection)
    blurred = cv2.GaussianBlur(gray, (7, 7), 0)

    # Finds contours using edges found with Canny Edge Detection
    edges = cv2.Canny(blurred, 15, 150)
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    holds = []
    for contour in contours:
        area = cv2.contourArea(contour)
        if 35 < area:
            x, y, w, h = cv2.boundingRect(contour)
            line = f"{x} {y} {w} {h} {area}"
            holds.append(line)

    write(holds)

    return holds

#write holds to file for route maker file
def write(holds):
    output_path = os.path.join("static/uploads", "holds_list")
    with open(output_path, "w") as file:
        for hold in holds:
            file.write(str(hold) + "\n")

#dikjstrater
def dikjstrater(holds):
    process = subprocess.Popen(['holds.exe', 'holds_list'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = process.communicate()
    return list(map(int, stdout.decode().strip().split()))

#output
def output(image_path, numbers):
    image = cv2.imread(image_path)

    #draw start
    x, y, w, h = numbers[0:4]
    top_left = (x, y)
    bottom_right = (x + w, y + h)
    cv2.rectangle(image, top_left, bottom_right, color=(0, 255, 0), thickness=2)

    #draw finish
    x, y, w, h = numbers[len(numbers) - 4:len(numbers)]
    top_left = (x, y)
    bottom_right = (x + w, y + h)
    cv2.rectangle(image, top_left, bottom_right, color=(0, 0, 255), thickness=2)

    #draw middle holds
    for i in range(4, len(numbers) - 4, 4):
        x, y, w, h = numbers[i:i+4]
        top_left = (x, y)
        bottom_right = (x + w, y + h)
        cv2.rectangle(image, top_left, bottom_right, color=(255, 0, 0), thickness=2)

    output_path = os.path.join("static/uploads", "holds_output.jpg")
    cv2.imwrite(output_path, image)

    '''
    cv2.imshow("Image with Boxes", image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    '''

def main_function(image_path, difficulty):

    holds = detect_holds(image_path)

    # Call route maker
    numbers = dikjstrater(holds)

    output(image_path, numbers)
